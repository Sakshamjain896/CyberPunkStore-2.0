import React, { createContext, useContext, useState, useEffect } from 'react';

const StoreContext = createContext();

export const useStore = () => useContext(StoreContext);

export const StoreProvider = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userCredits, setUserCredits] = useState(5000);
  const [cart, setCart] = useState([]);
  const [currentTier, setCurrentTier] = useState(0);
  const [scanlinesActive, setScanlinesActive] = useState(false);
  const [lowPowerMode, setLowPowerMode] = useState(false);
  const [primaryColor, setPrimaryColor] = useState('#00f2ff');
  const [hackDiscountActive, setHackDiscountActive] = useState(false);

  const tiers = [
    { name: "NEOPHYTE", cost: 0, discount: 0, perks: ["Ads Included", "Standard Marketplace"] },
    { name: "OPERATIVE", cost: 29, discount: 0.05, perks: ["No System Ads", "5% Discount", "Priority Uplink"] },
    { name: "ARCHITECT", cost: 99, discount: 0.20, perks: ["No System Ads", "20% Discount", "AI Assistant", "Admin Clearance"] }
  ];

  const products = [
    { id: 1, type: 'hardware', name: "NEURAL LINK V1", price: "2400 CR", desc: "Biometric interface." },
    { id: 2, type: 'software', name: "CORTEX OS", price: "5000 CR", desc: "AI Kernel." },
    { id: 3, type: 'hardware', name: "OPTIC AUGMENT", price: "1200 CR", desc: "Visual enhancer." },
    { id: 4, type: 'software', name: "GHOST PROTOCOL", price: "8000 CR", desc: "Stealth routing." },
    { id: 5, type: 'hardware', name: "NANO BATTERY", price: "450 CR", desc: "Energy cell." },
    { id: 6, type: 'hardware', name: "SYNAPSE BOOSTER", price: "3200 CR", desc: "Reaction overclock." }
  ];

  const parsePrice = (s) => parseInt(s.replace(/[^0-9]/g, ''));

  const addToCart = (id) => {
    const product = products.find(p => p.id === id);
    if (product) {
      setCart([...cart, product]);
    }
  };

  const removeFromCart = (index) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  const buyCredits = (amount) => {
    setUserCredits(prev => prev + amount);
  };

  const deductCredits = (amount) => {
    if (userCredits >= amount) {
      setUserCredits(prev => prev - amount);
      return true;
    }
    return false;
  };

  const clearCart = () => {
    setCart([]);
  };

  const login = () => {
    setIsLoggedIn(true);
  };

  const logout = () => {
    setIsLoggedIn(false);
    setCart([]);
    setUserCredits(5000);
    setCurrentTier(0);
  };

  const activatePlan = (tierIndex) => {
    const cost = tiers[tierIndex].cost;
    if (deductCredits(cost)) {
      setCurrentTier(tierIndex);
      return true;
    }
    return false;
  };

  const getCartTotal = () => {
    const subtotal = cart.reduce((sum, item) => sum + parsePrice(item.price), 0);
    let discount = Math.floor(subtotal * tiers[currentTier].discount);
    
    // Add 50% hack discount if active
    if (hackDiscountActive) {
      discount = Math.floor(subtotal * 0.5);
    }
    
    return { subtotal, discount, total: subtotal - discount };
  };

  const setTheme = (color) => {
    setPrimaryColor(color);
    document.documentElement.style.setProperty('--primary', color);
  };

  const activateHackDiscount = () => {
    setHackDiscountActive(true);
  };

  const clearHackDiscount = () => {
    setHackDiscountActive(false);
  };

  const value = {
    isLoggedIn,
    userCredits,
    cart,
    currentTier,
    tiers,
    products,
    scanlinesActive,
    lowPowerMode,
    primaryColor,
    hackDiscountActive,
    addToCart,
    removeFromCart,
    buyCredits,
    deductCredits,
    clearCart,
    login,
    logout,
    activatePlan,
    getCartTotal,
    parsePrice,
    setScanlinesActive,
    setLowPowerMode,
    setTheme,
    activateHackDiscount,
    clearHackDiscount
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
};
