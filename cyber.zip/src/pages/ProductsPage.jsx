import React, { useState, useEffect } from 'react';
import gsap from 'gsap';
import { useStore } from '../context/StoreContext';
import { useAudio } from '../hooks/useAudio';
import AuthModal from '../components/AuthModal';

const ProductsPage = ({ onOpenCart }) => {
  const { products, addToCart, isLoggedIn, cart } = useStore();
  const { playCoinSound } = useAudio();
  const [filter, setFilter] = useState('all');
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleAddToCart = (id) => {
    if (!isLoggedIn) {
      setShowAuthModal(true);
      return;
    }
    addToCart(id);
    playCoinSound();
    gsap.from("#cart-count", { scale: 2, duration: 0.3 });
  };

  const handleFilter = (type) => {
    setFilter(type);
    gsap.fromTo(
      ".product-card",
      { opacity: 0, y: 50 },
      { opacity: 1, y: 0, stagger: 0.1, duration: 0.5 }
    );
  };

  const filteredProducts = filter === 'all' ? products : products.filter(p => p.type === filter);

  return (
    <div className="page-container" style={{
      padding: '40px 5%',
      paddingTop: '120px',
      width: '100%',
      display: 'block',
      opacity: 1,
      flex: 1,
      position: 'relative'
    }}>
      {/* Page Title */}
      <div style={{ textAlign: 'center', marginBottom: '60px' }}>
        <h1 style={{
          fontSize: 'clamp(2.5rem, 6vw, 4.5rem)',
          fontWeight: '900',
          color: '#fff',
          marginBottom: '15px',
          letterSpacing: '8px',
          textTransform: 'uppercase',
          textShadow: `0 0 20px var(--primary), 0 0 40px var(--primary)`,
          animation: 'neon-flicker 3s infinite'
        }}>
          <span style={{ color: 'var(--primary)' }}>CYBER</span> MARKETPLACE
        </h1>
        <p style={{
          fontSize: '1.1rem',
          color: 'rgba(255,255,255,0.6)',
          fontFamily: 'Space Mono',
          letterSpacing: '3px'
        }}>
          // AUGMENTATIONS & SOFTWARE UPGRADES
        </p>
      </div>

      <div className="filter-bar" style={{
        display: 'flex',
        justifyContent: 'center',
        gap: '15px',
        marginBottom: '50px',
        flexWrap: 'wrap',
        alignItems: 'center'
      }}>
        <button className="epic-btn" onClick={() => handleFilter('all')}>ALL</button>
        <button className="epic-btn" onClick={() => handleFilter('hardware')}>HARDWARE</button>
        <button className="epic-btn" onClick={() => handleFilter('software')}>SOFTWARE</button>
        <button
          className="epic-btn"
          onClick={onOpenCart}
          style={{
            marginLeft: '30px',
            borderColor: 'var(--primary)',
            color: 'var(--primary)'
          }}
        >
          CART [<span id="cart-count">{cart.length}</span>]
        </button>
      </div>

      <div className="grid-container" style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
        gap: '40px',
        paddingBottom: '100px',
        width: '100%',
        perspective: '1500px'
      }}>
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="product-card"
            style={{
              position: 'relative',
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid rgba(255, 255, 255, 0.05)',
              padding: '30px',
              borderRadius: '0px',
              cursor: 'pointer',
              transformStyle: 'preserve-3d',
              transition: 'border-color 0.3s'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--primary)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.05)';
            }}
          >
            <div
              className="price-tag"
              style={{
                position: 'absolute',
                top: 0,
                right: 0,
                fontSize: '0.7rem',
                color: 'black',
                background: 'var(--primary)',
                fontWeight: 700,
                padding: '5px 15px',
                transform: 'translateZ(40px)'
              }}
            >
              {product.price}
            </div>
            <div className="card-inner" style={{
              transform: 'translateZ(30px)',
              pointerEvents: 'none',
              position: 'relative',
              zIndex: 1
            }}>
              <h4
                className="hacker-text"
                style={{
                  fontFamily: 'Space Mono, monospace',
                  fontSize: '1.4rem',
                  marginBottom: '10px',
                  color: 'white',
                  letterSpacing: '-1px',
                  fontWeight: 700
                }}
              >
                {product.name}
              </h4>
              <div
                className="tech-line"
                style={{
                  width: '20px',
                  height: '3px',
                  background: 'var(--primary)',
                  margin: '15px 0'
                }}
              />
              <p>{product.desc}</p>
              <button
                className="epic-btn"
                style={{ width: '100%', pointerEvents: 'auto' }}
                onClick={(e) => {
                  e.stopPropagation();
                  handleAddToCart(product.id);
                }}
              >
                ACQUIRE
              </button>
            </div>
          </div>
        ))}
      </div>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
};

export default ProductsPage;
