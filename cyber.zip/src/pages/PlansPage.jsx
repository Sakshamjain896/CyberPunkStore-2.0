import React, { useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { useAudio } from '../hooks/useAudio';
import gsap from 'gsap';

function PlansPage({ onNavigate }) {
  const { tiers, currentTier, isLoggedIn, activatePlan } = useStore();
  const { playCoinSound, playErrorSound, speakSystem } = useAudio();

  useEffect(() => {
    gsap.fromTo('.tier-card',
      { opacity: 0, y: 50 },
      { opacity: 1, y: 0, duration: 0.8, stagger: 0.2, ease: 'power2.out' }
    );
  }, []);

  const handleActivate = (tierIndex) => {
    if (!isLoggedIn) {
      playErrorSound();
      speakSystem('Login required.');
      return;
    }

    if (tierIndex <= currentTier) {
      playErrorSound();
      speakSystem('Already at this tier or higher.');
      return;
    }

    const success = activatePlan(tierIndex);
    if (success) {
      playCoinSound();
      speakSystem(`${tiers[tierIndex].name} tier activated.`);
    } else {
      playErrorSound();
      speakSystem('Insufficient credits.');
    }
  };

  return (
    <div id="plans-view" style={{
      height: '100vh',
      overflowY: 'auto',
      padding: '120px 20px 80px'
    }}>
      <div className="content-wrapper" style={{ maxWidth: '1400px', margin: '0 auto' }}>
        <h1 className="page-title" style={{
          fontSize: 'clamp(2.5rem, 5vw, 4rem)',
          marginBottom: '20px',
          color: 'var(--primary)',
          textAlign: 'center'
        }}>
          SUBSCRIPTION TIERS
        </h1>

        <p style={{
          textAlign: 'center',
          fontSize: '1.1rem',
          color: 'rgba(255,255,255,0.6)',
          marginBottom: '60px',
          maxWidth: '600px',
          margin: '0 auto 60px'
        }}>
          Upgrade your access level for exclusive benefits and discounts
        </p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '30px',
          padding: '20px 0'
        }}>
          {tiers.map((tier, index) => (
            <div
              key={index}
              className="tier-card"
              style={{
                background: 'var(--glass)',
                border: currentTier === index ? '2px solid var(--primary)' : '1px solid rgba(255,255,255,0.1)',
                borderRadius: '12px',
                padding: '40px 30px',
                position: 'relative',
                transition: 'all 0.3s ease',
                boxShadow: currentTier === index ? '0 0 30px rgba(0, 242, 255, 0.3)' : 'none',
                transform: currentTier === index ? 'scale(1.05)' : 'scale(1)'
              }}
            >
              {currentTier === index && (
                <div style={{
                  position: 'absolute',
                  top: '-12px',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  background: 'var(--primary)',
                  color: '#000',
                  padding: '4px 16px',
                  borderRadius: '12px',
                  fontSize: '0.75rem',
                  fontWeight: '700',
                  letterSpacing: '1px'
                }}>
                  CURRENT TIER
                </div>
              )}

              <div style={{
                textAlign: 'center',
                marginBottom: '30px'
              }}>
                <h3 style={{
                  fontSize: '1.8rem',
                  fontWeight: '700',
                  color: index === 0 ? '#888' : index === 1 ? 'var(--primary)' : '#ff0055',
                  marginBottom: '15px',
                  textTransform: 'uppercase',
                  letterSpacing: '2px'
                }}>
                  {tier.name}
                </h3>

                <div style={{
                  fontSize: '3rem',
                  fontWeight: '900',
                  color: '#fff',
                  marginBottom: '10px'
                }}>
                  {tier.cost === 0 ? 'FREE' : `${tier.cost} CR`}
                </div>

                {tier.discount > 0 && (
                  <div style={{
                    fontSize: '1.2rem',
                    color: '#00ff41',
                    fontWeight: '700'
                  }}>
                    {tier.discount}% DISCOUNT
                  </div>
                )}
              </div>

              <div style={{
                marginBottom: '30px',
                paddingTop: '20px',
                borderTop: '1px solid rgba(255,255,255,0.1)'
              }}>
                <div style={{
                  fontSize: '0.9rem',
                  color: 'rgba(255,255,255,0.7)',
                  lineHeight: '2.2'
                }}>
                  {index === 0 && (
                    <>
                      <div>✓ Access to product catalog</div>
                      <div>✓ Standard support</div>
                      <div>✓ Basic features</div>
                      <div>✓ Community forum access</div>
                      <div style={{ opacity: 0.3 }}>✗ No discounts</div>
                      <div style={{ opacity: 0.3 }}>✗ No priority support</div>
                    </>
                  )}
                  {index === 1 && (
                    <>
                      <div>✓ 5% discount on all products</div>
                      <div>✓ Priority support</div>
                      <div>✓ Early access to new items</div>
                      <div>✓ Exclusive OPERATIVE badge</div>
                      <div>✓ Monthly product updates</div>
                      <div>✓ Private Discord channel</div>
                    </>
                  )}
                  {index === 2 && (
                    <>
                      <div>✓ 20% discount on all products</div>
                      <div>✓ VIP support 24/7</div>
                      <div>✓ First access to beta products</div>
                      <div>✓ AI Assistant enabled</div>
                      <div>✓ Exclusive ARCHITECT badge</div>
                      <div>✓ Private community access</div>
                      <div>✓ Custom product requests</div>
                      <div>✓ Quarterly strategy calls</div>
                    </>
                  )}
                </div>
              </div>

              <button
                className="epic-btn"
                onClick={() => handleActivate(index)}
                disabled={currentTier >= index}
                style={{
                  width: '100%',
                  padding: '15px',
                  fontSize: '1rem',
                  fontWeight: '700',
                  letterSpacing: '1px',
                  opacity: currentTier >= index ? 0.5 : 1,
                  cursor: currentTier >= index ? 'not-allowed' : 'pointer'
                }}
              >
                {currentTier === index ? 'CURRENT TIER' : currentTier > index ? 'TIER UNLOCKED' : tier.cost === 0 ? 'DEFAULT TIER' : 'ACTIVATE'}
              </button>
            </div>
          ))}
        </div>

        <div style={{
          marginTop: '80px',
          padding: '40px',
          background: 'var(--glass)',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: '12px',
          textAlign: 'center'
        }}>
          <h3 style={{
            fontSize: '1.5rem',
            marginBottom: '15px',
            color: 'var(--primary)'
          }}>
            NEED MORE CREDITS?
          </h3>
          <p style={{
            color: 'rgba(255,255,255,0.6)',
            marginBottom: '20px'
          }}>
            Visit the Wallet page to purchase additional credits
          </p>
          <button
            className="epic-btn"
            onClick={() => onNavigate && onNavigate('wallet-view')}
            style={{
              padding: '12px 40px',
              fontSize: '0.9rem'
            }}
          >
            GO TO WALLET
          </button>
        </div>
      </div>
    </div>
  );
}

export default PlansPage;
