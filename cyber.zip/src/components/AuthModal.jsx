import React, { useState } from 'react';
import gsap from 'gsap';
import { useStore } from '../context/StoreContext';
import { useAudio } from '../hooks/useAudio';

const AuthModal = ({ isOpen, onClose }) => {
  const [mode, setMode] = useState('login');
  const { login } = useStore();
  const { playCoinSound, speakSystem } = useAudio();

  const handleAuth = () => {
    const btn = document.querySelector('#auth-form-container button');
    if (btn) btn.innerText = "VERIFYING...";
    
    setTimeout(() => {
      login();
      playCoinSound();
      onClose();
      speakSystem("Identity verified. Welcome back, Operative.");
    }, 1500);
  };

  const toggleMode = (newMode) => {
    setMode(newMode);
    gsap.to("#auth-form-container", {
      opacity: 0,
      duration: 0.2,
      onComplete: () => {
        gsap.to("#auth-form-container", { opacity: 1, duration: 0.2 });
      }
    });
  };

  React.useEffect(() => {
    if (isOpen) {
      gsap.to("#auth-overlay", { opacity: 1, duration: 0.3 });
      gsap.to(".auth-box", { scaleY: 1, duration: 0.5, ease: "power4.out" });
    }
  }, [isOpen]);

  const handleClose = () => {
    gsap.to(".auth-box", { scaleY: 0, duration: 0.3, ease: "power4.in" });
    gsap.to("#auth-overlay", {
      opacity: 0,
      duration: 0.3,
      delay: 0.2,
      onComplete: onClose
    });
  };

  if (!isOpen) return null;

  return (
    <div
      id="auth-overlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        background: 'rgba(2, 2, 5, 0.6)',
        backdropFilter: 'blur(15px)',
        zIndex: 3000,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        opacity: 0,
        pointerEvents: 'auto'
      }}
    >
      <div
        className="auth-box"
        style={{
          width: '100%',
          maxWidth: '400px',
          background: 'rgba(10, 15, 20, 0.8)',
          border: '1px solid rgba(255,255,255,0.1)',
          padding: '40px',
          position: 'relative',
          transform: 'scaleY(0)',
          overflow: 'hidden',
          boxShadow: '0 0 50px rgba(0, 242, 255, 0.1)'
        }}
      >
        <div style={{
          content: '',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '2px',
          background: 'var(--primary)',
          boxShadow: '0 0 20px var(--primary)'
        }} />

        <div className="auth-header" style={{ textAlign: 'center', marginBottom: '30px' }}>
          <div className="auth-title" style={{ fontSize: '2rem', fontWeight: 900, letterSpacing: '5px', color: 'white', marginBottom: '5px' }}>
            ACCESS
          </div>
          <div className="auth-subtitle" style={{ fontFamily: 'Space Mono', fontSize: '0.7rem', color: 'var(--primary)' }}>
            SECURE NEURAL LINK
          </div>
        </div>

        <div className="auth-toggle-bar" style={{ display: 'flex', marginBottom: '30px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <div
            className={`auth-tab ${mode === 'login' ? 'active' : ''}`}
            onClick={() => toggleMode('login')}
            style={{
              flex: 1,
              textAlign: 'center',
              padding: '10px',
              cursor: 'pointer',
              fontFamily: 'Space Mono',
              fontSize: '0.8rem',
              color: mode === 'login' ? 'white' : '#666',
              transition: '0.3s',
              borderBottom: mode === 'login' ? '2px solid var(--primary)' : 'none'
            }}
          >
            LOGIN
          </div>
          <div
            className={`auth-tab ${mode === 'signup' ? 'active' : ''}`}
            onClick={() => toggleMode('signup')}
            style={{
              flex: 1,
              textAlign: 'center',
              padding: '10px',
              cursor: 'pointer',
              fontFamily: 'Space Mono',
              fontSize: '0.8rem',
              color: mode === 'signup' ? 'white' : '#666',
              transition: '0.3s',
              borderBottom: mode === 'signup' ? '2px solid var(--primary)' : 'none'
            }}
          >
            INITIALIZE
          </div>
        </div>

        <div id="auth-form-container">
          <input type="email" placeholder="IDENTITY (EMAIL)" className="auth-input" style={{
            width: '100%',
            background: 'rgba(255,255,255,0.02)',
            border: '1px solid rgba(255,255,255,0.1)',
            padding: '15px',
            marginBottom: '20px',
            color: 'white',
            outline: 'none',
            fontFamily: 'Space Grotesk',
            transition: '0.3s'
          }} />
          <input type="password" placeholder="PASSPHRASE" className="auth-input" style={{
            width: '100%',
            background: 'rgba(255,255,255,0.02)',
            border: '1px solid rgba(255,255,255,0.1)',
            padding: '15px',
            marginBottom: '20px',
            color: 'white',
            outline: 'none',
            fontFamily: 'Space Grotesk',
            transition: '0.3s'
          }} />
          {mode === 'signup' && (
            <input type="password" placeholder="CONFIRM PASSPHRASE" className="auth-input" style={{
              width: '100%',
              background: 'rgba(255,255,255,0.02)',
              border: '1px solid rgba(255,255,255,0.1)',
              padding: '15px',
              marginBottom: '20px',
              color: 'white',
              outline: 'none',
              fontFamily: 'Space Grotesk',
              transition: '0.3s'
            }} />
          )}
          <button className="epic-btn" style={{ width: '100%', marginTop: '10px' }} onClick={handleAuth}>
            {mode === 'login' ? 'ESTABLISH LINK' : 'INITIALIZE ID'}
          </button>
          <div
            style={{
              textAlign: 'center',
              marginTop: '20px',
              fontSize: '0.7rem',
              color: '#666',
              cursor: 'pointer'
            }}
            onClick={handleClose}
          >
            [ CANCEL UPLINK ]
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
