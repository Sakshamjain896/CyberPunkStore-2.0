# NeonDream - Cyberpunk Store

A futuristic cyberpunk-themed e-commerce platform built with React, Three.js, and cutting-edge web technologies.

## Features

- 🎨 **Cyberpunk Aesthetic**: Neon colors, glitch effects, and retro-futuristic design
- 🌌 **3D Interactive Background**: React Three Fiber powered starfield and cyber grid
- 🔐 **User Authentication**: Login/Register system with credit-based payments
- 🛒 **Shopping Cart**: Full e-commerce functionality
- 📱 **Responsive Design**: Works seamlessly on all devices
- ⚡ **Fast Performance**: Built with Vite for lightning-fast development

## Tech Stack

- **React 18** - UI framework
- **React Router** - Navigation
- **React Three Fiber** - 3D graphics
- **Vite** - Build tool
- **CSS3** - Styling with custom properties

## Getting Started

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Project Structure

```
neondream/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── layout/       # Header, Footer, Layout
│   │   ├── ui/           # Reusable UI components
│   │   └── three/        # 3D scene components
│   ├── context/          # Global state management
│   ├── pages/            # Route pages
│   ├── styles/           # Global styles
│   ├── App.jsx           # Main app component
│   └── main.jsx          # Entry point
├── package.json
└── vite.config.js
```

## Features Implemented

### ✅ Phase 1 - Landing Page & Authentication
- Landing page with 3D background
- Login/Register modal system
- User context for authentication
- Header with navigation
- Footer with links
- Responsive design

### 🚧 Coming Soon
- Product catalog
- Shopping cart panel
- Subscription plans
- User profile dashboard
- Audio system
- Advanced 3D elements (Globe, Data Core)

## Development

The project uses:
- **CSS Variables** for theming
- **Context API** for state management
- **Local Storage** for persistence
- **Custom hooks** for reusable logic

## License

MIT License - feel free to use this project for learning or commercial purposes.

## Credits

Built with ❤️ using React and Three.js
